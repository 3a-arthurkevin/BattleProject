T�ches effectu�es par Pierre

	> Cr�ation des classes de bases :
		- Capacity
		- Toutes les classes h�ritant de Capacity
		- Unit
		- Army
	> Sortie fichier texte sauvegarde
	> Commentaires code


T�ches effectu�es par Kevin

	> Creation de la class IA
	> Loop d'un combat
	> Croissement g�n�rtique / Mutation
	> Retouches sur quelques classes de bases (ajout de fonctions non pr�sentes dans l'enonc� facilitant les batailles)
	> Commentaires code (tranduction anglais)



Par soucis de temps de simulation trop long lors d'un bataille entre 2 arm�es, quelques modifications ont �t� ajout�es
	--> WeaponSpeed plus petit (remplacement de la formule 1000/(lvl + 1) par 10/(lvl + 1) )
	--> une bataille entre 2 arm�es ne peut faire plus de 1000 tours (choix du gagnant � celui qui a le plus d'unit� survivant ou random en cas d'egalit�)


__________________________________________________________________________



Comment utiliser le programme : 

	> Entrez un I (nb it�ration      doit etre un nombre)
	> Entrez un T (crit�re score     doit etre un nombre)
	> Entrez un N (nb arm�e          doit etre un nombre)
	> Entrez un X (nb unit�          doit etre un nombre)
	> Entrez un Y (niveau global     doit etre un nombre)

	Attendre que le programme mouline

	Tout au long de la simulation, des sorties textes indiquerons les tours, les actions effectu�es et les scores
	
	Lors de la fin de la simulation, le programme indiquera ou le fichier de sauvegarde aura �t� cr�e
	
	Pour fermer la programme � la fin, entrez n'importe quel caract�re dans la console et appuiez sur "Entr�e"