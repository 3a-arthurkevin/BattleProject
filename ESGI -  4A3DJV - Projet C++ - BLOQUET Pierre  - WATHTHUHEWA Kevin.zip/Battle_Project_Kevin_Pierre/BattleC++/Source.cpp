enum class ActionType
{
	None,
	Shoot,
	Move,
};