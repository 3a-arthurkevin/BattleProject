#ifndef ACTIONTYPE_H
#define ACTIONTYPE_H

enum class ActionType
{
	None,
	Shoot,
	Move,
	Flee,
};

#endif